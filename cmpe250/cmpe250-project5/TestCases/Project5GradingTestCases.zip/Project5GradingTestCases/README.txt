Score information for each testcase type is as follows:

Corner 2
DNA 5
H 3
Limit 8
Mid 4
Switch 3

A total of 102 points with 2 points of bonus.
If you scored higher than 100 your score will be 100.