#ifndef SENSORDATA_H
#define SENSORDATA_H

#include "LPC407x_8x_177x_8x.h"

#define WINDOW_SIZE 3

typedef int32_t sensor_data_t;

const uint32_t dataSize = 21;
const sensor_data_t sensorData[] = {1, 2, 3, 4, 6, 8, 10, 13, 18, 22, 26, 30, 34, 36, 38, 40, 40, 40, 39, 37, 35};

	
#endif
