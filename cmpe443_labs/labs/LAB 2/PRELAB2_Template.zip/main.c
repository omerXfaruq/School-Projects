#include "LPC407x_8x_177x_8x.h"
#include "SensorData.h"

sensor_data_t filteredSensorData[dataSize];
	
void medianFilter(const sensor_data_t* data, sensor_data_t* result, uint32_t size) {
	
}

void init() {
}

void update() {
	medianFilter(sensorData, filteredSensorData, dataSize);
}

int main() {
	init();

	while(1) {
		update();
	}
}
